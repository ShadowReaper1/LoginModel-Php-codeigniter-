<html>  
   <head>  
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
      <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <style>
         .demo-card-wide.mdl-card {
            width: 1024px;
        margin: 0 auto;
         }
    .demo-card-wide > .mdl-card__title {
        color: #fff;
        height: 60px;
        background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/210284/welcome_card_tuts.png') center / cover;
        }
    .demo-card-wide > .mdl-card__menu {
        color: #fff;
    }

    body {
        padding: 50px 0 0;
        background: #fafafa;
        position: relative;
  }
    </style>
      <title>Home</title>  
   </head>  
   <body> 
             
             <br>
             <div class="mdl-card mdl-shadow--2dp demo-card-wide">
      <div class="mdl-card__title">
        <h2 class="mdl-card__title-text"><?php 
            echo $header;?><br></h2>
      </div>
      <div class="mdl-card__supporting-text">
        <?php
            echo $description;?><br>
      </div>
      <div class="mdl-card__actions mdl-card--border">
        <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Like(<?php echo $likecount; ?> )
        </a>
          <a href='#' class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Comment
        </a>
          <a href="#" class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Sign
        </a>
      </div>
      
    </div>
 
</body>  
</html>




