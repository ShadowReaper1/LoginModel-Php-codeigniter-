<html>  
   <head>  
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
      <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <style>
         .demo-card-wide.mdl-card {
            width: 1024px;
        margin: 0 auto;
         }
    .demo-card-wide > .mdl-card__title {
        color: #fff;
        height: 60px;
        background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/210284/welcome_card_tuts.png') center / cover;
        }
    .demo-card-wide > .mdl-card__menu {
        color: #fff;
    }

    body {
        padding: 50px 0 0;
        background: #fafafa;
        position: relative;
  }
    </style>
    
      <title>Home</title>  
   </head>  
   <body background="<?php echo base_url(); ?>banner.jpg"> 
       <form id="frm_login" role="form" action="http://localhost/login/index.php/home/sort/" method="POST"/>
       <div class="mdl-select mdl-js-select mdl-select--floating-label">
            <select class="mdl-select__input" id="category" name="category">
            <option value=""></option>
            <option value="1">option 1</option>
            <option value="2">option 2</option>
            <option value="3">option 3</option>
            <option value="4">option 4</option>
            <option value="5">option 5</option>
            </select>
            <label class="mdl-select__label" for="category">catgeory</label>
             <input type="submit"  value="submit"/>
        </div>
         <?php  
         foreach ($h->result() as $row)  
         {  
             ?>
             
             <br>
             <div class="mdl-card mdl-shadow--2dp demo-card-wide">
      <div class="mdl-card__title">
        <h2 class="mdl-card__title-text"><?php 
            echo $row->header;
            $r=$row->id ?> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <?php 
            echo $row->Category;?></h2>
      </div>
      <div class="mdl-card__supporting-text">
        <?php
            echo $row->description;?><br>
      </div>
      <div class="mdl-card__actions mdl-card--border">
        <a href="http://localhost/login/index.php/home/like/<?php echo $r;?>/<?php echo $row->likecount; ?>" class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Like(<?php echo $row->likecount; ?>)
        </a>
          <a href='<?php echo base_url();?>index.php/home/getcomment/<?php echo $row->id?>' class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Comment
        </a>
          <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Sign
        </a>
      </div>
      
    </div>
              <?php 
         }   
      ?>  
 
</body>  
</html>




