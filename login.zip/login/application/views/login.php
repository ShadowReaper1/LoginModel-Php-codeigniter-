<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>login page</title>
        <style>

.demo-layout-transparent .mdl-layout__header,
.demo-layout-transparent .mdl-layout__drawer-button {
  /* This background is dark, so we set text to white. Use 87% black instead if
     your background is light. */
  color: white;
}

</style>
        <?php $this->load->helper('url');?>
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script src="http://code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>css/material.min.css">
        <script src="<?php echo base_url(); ?>js/material.min.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
         
        
    </head>
    <body>
        
        <div class="container" style="margin-top: 10%">
            <div class="row clear_fix">
                <div class="col-md-6 col-md-offset-3">
                    <p class="alert alert-danger" id="response"><b>INVALID USER NAME OR PASSWORD</b></p>
                    <form id="frm_login" role="form" action="http://localhost/login/index.php/auth/login" method="POST">
                        <div class="mdl-textfield mdl-js-textfield">
                          
                          <input type="text" class="mdl-textfield__input" name="username"  placeholder="User name">
                        </div>
                        <div class="mdl-textfield mdl-js-textfield">
                          
                          <input type="password" class="mdl-textfield__input" name="password"  placeholder="Password">
                        </div>
                        <div>
                        <input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent" value="submit">
                        </div>
                        </form>
                     
                </div>
            </div>
        </div>
        <script>
        $(document).ready(function (){
            $("#frm_login").submit(function (e){
                e.preventDefault();
                var url = $(this).attr('action');
                var method = $(this).attr('method');
                var data = $(this).serialize();
                 
                $.ajax({
                   url:url,
                   type:method,
                   data:data
                }).done(function(data){
                   if(data !=='')
                    {
                        
                        $("#response").effect( "shake" );
                        $("#response").show('fast');
                        $('#frm_login')[0].reset();
                    }
                    else
                    {
                    window.location.href='<?php echo base_url() ?>/index.php/home/';
                    throw new Error('go');
                    } 
                });
            });
             
            $( "div" ).each(function( index ) {
            var cl = $(this).attr('class');
            if(cl =='')
                {
                    $(this).hide();
                }
            });
             
        });
        </script>
         
    </body>
</html>