<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <?php $this->load->helper('url');?>
        <html>  
   <head>  
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
      <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
         body {
    padding: 40px 0 0;
    background: #fafafa;
    text-align: center;
  }

button.mdl-button {
  margin: 30px;
  position:relative;
  left: 50px;
  top: 50px;
}
    </style>
        <title>home page</title>
    </head>
    <body>
        <div class="container">
            <div class="row clear_fix">
                <div class="col-md-12 ">
                     <br>
                     <a href="http://localhost/login/index.php/home/petition" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent mdl-js-ripple-effect">New Petition</a></button>
                     &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                     <a href="http://localhost/login/index.php/auth/logout" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent mdl-js-ripple-effect">Logout</a></button>
                     <br>
                </div>
            </div>
        </div>
        
        
    </body>
</html>