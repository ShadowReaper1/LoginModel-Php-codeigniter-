<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>login page</title>
        <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <style>
         .demo-card-wide.mdl-card {
            width: 1024px;
        margin: 0 auto;
         }
    .demo-card-wide > .mdl-card__title {
        color: #fff;
        height: 60px;
        background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/210284/welcome_card_tuts.png') center / cover;
        }
    .demo-card-wide > .mdl-card__menu {
        color: #fff;
    }

    body {
        padding: 50px 0 0;
        background: #fafafa;
        position: relative;
  }
    </style>
        
        
         
        
    </head>
    <body>
        
        <div class="container" style="margin-top: 10%">
            <div class="row clear_fix">
                <div class="col-md-6 col-md-offset-3">
                    <?php $this->load->helper('url');?>
         <?php  
         foreach ($h->result() as $row)  
         {  
         ?>
             
             
      <div class="mdl-card mdl-shadow--2dp demo-card-wide">
      <div class="mdl-card__title">
        <h2 class="mdl-card__title-text"><?php 
            echo $row->header;
            $r=$row->id ?><br></h2>
      </div>
      <div class="mdl-card__supporting-text">
        <?php
            echo $row->description;?><br>
      </div>
      <div class="mdl-card__actions mdl-card--border">
          <a href="http://localhost/login/index.php/home/like/<?php echo $r;?>/<?php echo $row->likecount; ?>" class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Like(<?php echo $row->likecount; ?>)
        </a>
          <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
          Sign
        </a>
      </div>
      
    </div>
              <?php 
         }   
      ?>  
 
                    <form id="frm_login" role="form" action="http://localhost/login/index.php/home/postcomment/<?php echo $r;?>" method="POST">
                        <div class="mdl-textfield mdl-js-textfield">
                          
                            <input size="250px" height="250px" type="text" class="mdl-textfield__input" name="comment"  placeholder="Place your Comments Here">
                        </div>
                        <div>
                        <input type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent" value="submit">
                        </div>
                        </form>
                     
                </div>
            </div>
        </div>
        
         
    </body>
</html>