<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Home extends CI_Controller {
        public function __construct() {
            parent::__construct();
            $this->load->Model('Auth_model'); 
            $this->load->helper(array('form', 'url'));
            
        }
 
 
        public function index(){
            //check user logged in or not
            $this->Auth_model->isLoggedIn();
            $this->load->view('home');
            $this->load->model('select');  
         //load the method of model  
            $data['h']=$this->select->select();  
         //return the data in view  
            $this->load->view('select_view', $data);
    }
     public function sort()
     {
         $category = $this->input->post('category');
         $this->Auth_model->isLoggedIn();
            $this->load->view('home');
            $this->load->model('select');  
            $data['h']=$this->select->sort($category);
            $this->load->view('select_view', $data);
            
     }
    
    public function getcomment()
    {
          
          $postid=$this->uri->segment(3);
          $this->Auth_model->isLoggedIn();
          $this->load->view('home');
          $this->load->model('select');
          $data['h']=$this->select->getcommments($postid);
          $this->load->view('comment', $data);
    }
    public function postcomment()
    {
        $postid=$this->uri->segment(3);
        $comment =  $this->input->post('comment');
        
        $this->Auth_model->isLoggedIn();
        $this->load->view('home');
        $this->load->model('select');
        $this->select->postcmnts($comment, $postid);
        $data['h']=$this->select->getcommments($postid);
        $this->load->view('comment', $data);
    }
     public function petition()
     {
         
         $this->Auth_model->isLoggedIn();
        $this->load->view('home');
        $this->load->model('select');
        $this->load->view('newpetition');
     }
     public function postpetition()
     {
        
         $header =  $this->input->post('header');
         $description =  $this->input->post('description');
         $category = $this->input->post('category');
         $this->load->view('home');
         $this->load->model('select');
         $this->select->postpetition($header, $description,$category);
         
            redirect('http://localhost/login/index.php/home/index');  
 
     }
     public function previewpetition()
     {
         $header =  $this->input->post('header');
         $description =  $this->input->post('description');
         $category = $this->input->post('category');
         
         $data =array(
             'header' => $header,
             'description' => $description,
             
         );
         $this->load->view('preview', $data);
     }
      public function like()
      {
          $postid=$this->uri->segment(3);
          $count=$this->uri->segment(4);
          $this->Auth_model->isLoggedIn();
          $this->load->view('home');
          $this->load->model('select');
          $this->select->like($postid,$count);
          redirect('http://localhost/login/index.php/home/index');  
      }
}
 
/* End of file home.php */
/* Location: ./application/controllers/home.php */