<?php  
   class select extends CI_Model  
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct();  
      }  
      //we will use the select function  
      public function select()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('petition');  
         return $query;  
      }  
      public function sort($category) {
          if($category!=0)
          {
          $sql="SELECT * FROM petition WHERE Category = ?";
          $q = $this->db->query($sql,$category);
          return $q;
          }
          else {
              $query = $this->db->get('petition');  
                return $query;
          }
      }
      
      public function getcommments($postid) {
        
          $sql="SELECT * FROM petition WHERE id = ?";
          $q = $this->db->query($sql,$postid);
          return $q;
      }
      public function postcmnts($comment, $postid){
          
          $data = array(
                'description'=>$comment,
                'postid'=>$postid,
            );
          $this->db->insert('comments',$data);
      }
      public function postpetition($header, $description,$category)
      {
          $data = array(
                'header'=>$header,
                'description'=>$description,
                'Category' =>$category,
            );
          $this->db->insert('petition',$data);
      }
      public function like($postid,$count)
      {
          $this->db->where('id', $postid);
          $count++;
          $data = array(
              'likecount'=> $count,
              );
          $this->db->update('petition' ,$data);
      }
   }  
?>