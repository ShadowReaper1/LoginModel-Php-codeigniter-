<h1>Submitted Data:</h1>
<pre><?php print_r($_GET) ?></pre>